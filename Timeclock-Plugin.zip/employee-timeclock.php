<?php
/**
 * Plugin Name: Simple Employee Time Clock
 * Description: Time clock with front-end admin and subscriber views
 * Version: 2.5
 */

if (!defined('ABSPATH')) {
    exit;
}

// Set timezone
function timeclock_set_timezone()
{
    date_default_timezone_set('America/New_York');
}
add_action('init', 'timeclock_set_timezone');

// Activation
function timeclock_activate()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'timeclock_entries';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        clock_in datetime NOT NULL,
        clock_out datetime DEFAULT NULL,
        notes text DEFAULT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Add capabilities to subscriber role
    $subscriber_role = get_role('subscriber');
    if ($subscriber_role) {
        $subscriber_role->add_cap('use_timeclock');
        $subscriber_role->add_cap('view_all_hours');
    }

    // Add capabilities to administrator role
    $admin_role = get_role('administrator');
    if ($admin_role) {
        $admin_role->add_cap('use_timeclock');
        $admin_role->add_cap('view_all_hours');
    }
}
register_activation_hook(__FILE__, 'timeclock_activate');

// Deactivation
function timeclock_deactivate()
{
    // Remove capabilities from subscriber role
    $subscriber_role = get_role('subscriber');
    if ($subscriber_role) {
        $subscriber_role->remove_cap('use_timeclock');
        $subscriber_role->remove_cap('view_all_hours');
    }

    // Remove capabilities from administrator role
    $admin_role = get_role('administrator');
    if ($admin_role) {
        $admin_role->remove_cap('use_timeclock');
        $admin_role->remove_cap('view_all_hours');
    }
}
register_deactivation_hook(__FILE__, 'timeclock_deactivate');

// Enqueue styles
function timeclock_enqueue_styles()
{
    wp_enqueue_style('timeclock-styles', plugins_url('timeclock-styles.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'timeclock_enqueue_styles');

// Get weekly hours
function get_weekly_hours($user_id)
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'timeclock_entries';

    $start_of_week = date('Y-m-d 00:00:00', strtotime('monday this week America/New_York'));
    $end_of_week = date('Y-m-d 23:59:59', strtotime('sunday this week America/New_York'));
    $current_time = date('Y-m-d H:i:s', strtotime('now America/New_York'));

    $total_hours = $wpdb->get_var($wpdb->prepare(
        "SELECT SUM(
            TIMESTAMPDIFF(MINUTE, clock_in, IFNULL(clock_out, %s)) / 60.0
        ) as total_hours
        FROM $table_name
        WHERE user_id = %d
        AND (
            (clock_in >= %s AND clock_in <= %s) 
            OR (clock_out >= %s AND clock_out <= %s)
            OR (clock_in <= %s AND (clock_out >= %s OR clock_out IS NULL))
        )",
        $current_time,
        $user_id,
        $start_of_week,
        $end_of_week,
        $start_of_week,
        $end_of_week,
        $start_of_week,
        $end_of_week
    ));

    return number_format($total_hours ?: 0, 2);
}

// Handle clock actions
function handle_timeclock_actions()
{
    if (!is_user_logged_in() || (!current_user_can('use_timeclock') && !current_user_can('manage_options'))) {
        return;
    }

    if (
        !isset($_POST['timeclock_nonce']) ||
        !wp_verify_nonce($_POST['timeclock_nonce'], 'timeclock_action')
    ) {
        return;
    }

    if (!isset($_POST['timeclock_action'])) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'timeclock_entries';
    $user_id = get_current_user_id();
    $current_time = date('Y-m-d H:i:s', strtotime('now America/New_York'));
    $notes = isset($_POST['clock_notes']) ? sanitize_textarea_field($_POST['clock_notes']) : '';

    if ($_POST['timeclock_action'] === 'clock_in') {
        // Ensure user isn't already clocked in
        $active_entry = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_name WHERE user_id = %d AND clock_out IS NULL",
            $user_id
        ));

        if (!$active_entry) {
            $wpdb->insert(
                $table_name,
                array(
                    'user_id' => $user_id,
                    'clock_in' => $current_time
                ),
                array('%d', '%s')
            );
        }
    } elseif ($_POST['timeclock_action'] === 'clock_out') {
        // Find the active entry first
        $active_entry = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM $table_name WHERE user_id = %d AND clock_out IS NULL",
            $user_id
        ));

        if ($active_entry) {
            $wpdb->update(
                $table_name,
                array(
                    'clock_out' => $current_time,
                    'notes' => $notes
                ),
                array('id' => $active_entry->id),
                array('%s', '%s'),
                array('%d')
            );
        }
    }
}
add_action('init', 'handle_timeclock_actions');

// Handle reset hours (admin only)
function handle_reset_hours()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    if (
        !isset($_POST['reset_nonce']) ||
        !wp_verify_nonce($_POST['reset_nonce'], 'reset_hours') ||
        !isset($_POST['user_id'])
    ) {
        return;
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'timeclock_entries';
    $user_id = intval($_POST['user_id']);

    $wpdb->delete($table_name, ['user_id' => $user_id], ['%d']);
}
add_action('init', 'handle_reset_hours');

// Main shortcode
function timeclock_shortcode()
{
    if (!is_user_logged_in()) {
        $login_url = wp_login_url(get_permalink());
        return '<div class="timeclock-container">
            <div class="timeclock-header">
                <h2>Employee Time Clock (EST)</h2>
            </div>
            <div class="timeclock-login">
                <p>Please log in to access the time clock system.</p>
                <a href="' . esc_url($login_url) . '" class="timeclock-button login-button">Login to WordPress</a>
            </div>
        </div>';
    }

    // Check if user has necessary permissions
    if (!current_user_can('use_timeclock') && !current_user_can('manage_options')) {
        return '<div class="timeclock-container">
            <div class="timeclock-header">
                <h2>Access Denied</h2>
                <a href="' . wp_logout_url(get_permalink()) . '" class="logout-button">Logout</a>
            </div>
            <div class="timeclock-message timeclock-error">
                You do not have permission to use the time clock system.
            </div>
        </div>';
    }

    ob_start();
    echo get_full_view();
    return ob_get_clean();
}
add_shortcode('timeclock', 'timeclock_shortcode');

// Get full view
function get_full_view()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'timeclock_entries';
    $current_user_id = get_current_user_id();
    $is_admin = current_user_can('manage_options');

    // Get current user's clock status
    $current_entry = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE user_id = %d AND clock_out IS NULL",
        $current_user_id
    ));

    // Get users based on role
    if ($is_admin) {
        $users = get_users(['role__in' => ['subscriber', 'administrator']]);
    } else {
        $users = get_users(['role' => 'subscriber']);
    }

    // Calculate total weekly hours for visible employees only
    $total_weekly_hours = 0;
    foreach ($users as $user) {
        // Skip admin hours in total for subscribers
        if (!$is_admin && user_can($user->ID, 'manage_options')) {
            continue;
        }
        $total_weekly_hours += floatval(get_weekly_hours($user->ID));
    }

    ob_start();
    ?>
    <div class="timeclock-container admin-view">
        <div class="timeclock-header">
            <h2>Time Clock System (EST)</h2>
            <div class="user-info">
                <span>Welcome, <?php echo wp_get_current_user()->display_name; ?></span>
                <a href="<?php echo wp_logout_url(get_permalink()); ?>" class="logout-button">Logout</a>
            </div>
        </div>

        <div class="personal-section">
            <h3>My Time Clock</h3>
            <div class="timeclock-stats">
                <div class="stat-box">
                    <label>My Weekly Hours:</label>
                    <span><?php echo get_weekly_hours($current_user_id); ?></span>
                </div>
                <div class="stat-box">
                    <label>Status:</label>
                    <span><?php echo $current_entry ? 'Clocked In' : 'Clocked Out'; ?></span>
                </div>
                <?php if ($current_entry): ?>
                    <div class="stat-box">
                        <label>Clock In Time:</label>
                        <span><?php echo date('g:i A', strtotime($current_entry->clock_in . ' America/New_York')); ?></span>
                    </div>
                <?php endif; ?>
            </div>

            <form method="post" class="timeclock-form">
                <?php
                $button_text = $current_entry ? 'Clock Out' : 'Clock In';
                $action = $current_entry ? 'clock_out' : 'clock_in';
                wp_nonce_field('timeclock_action', 'timeclock_nonce');
                ?>
                <input type="hidden" name="timeclock_action" value="<?php echo esc_attr($action); ?>">
                <?php if ($current_entry): ?>
                    <div class="notes-field" style="margin-bottom: 1rem; text-align: left;">
                        <label for="clock_notes" style="display: block; margin-bottom: 0.5rem;">Clock Out Notes:</label>
                        <textarea name="clock_notes" id="clock_notes" rows="2" style="width: 100%;"></textarea>
                    </div>
                <?php endif; ?>
                <button type="submit" class="timeclock-button <?php echo $action; ?>">
                    <?php echo esc_html($button_text); ?>
                </button>
            </form>
        </div>

        <div class="total-hours-summary">
            <div class="summary-box">
                <h3><?php echo $is_admin ? 'Total Weekly Hours (All Employees)' : 'Total Weekly Hours (Staff)'; ?></h3>
                <span class="total-hours"><?php echo number_format($total_weekly_hours, 2); ?></span>
            </div>
        </div>

        <?php foreach ($users as $user):
            if (!$is_admin && user_can($user->ID, 'manage_options')) {
                continue;
            }

            $weekly_hours = get_weekly_hours($user->ID);
            $entries = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table_name 
                WHERE user_id = %d 
                ORDER BY clock_in DESC 
                LIMIT 10",
                $user->ID
            ));
            ?>
            <div class="employee-section">
                <h3><?php echo esc_html($user->display_name); ?></h3>
                <div class="weekly-hours">Weekly Hours: <?php echo $weekly_hours; ?></div>

                <?php if ($is_admin): ?>
                    <form method="post" class="reset-form">
                        <?php wp_nonce_field('reset_hours', 'reset_nonce'); ?>
                        <input type="hidden" name="user_id" value="<?php echo $user->ID; ?>">
                        <button type="submit" class="reset-button"
                            onclick="return confirm('Are you sure you want to reset hours for this employee?')">
                            Reset Hours
                        </button>
                    </form>
                <?php endif; ?>

                <table class="time-entries">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Clock In</th>
                            <th>Clock Out</th>
                            <th>Hours</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $current_time = date('Y-m-d H:i:s', strtotime('now America/New_York'));
                        foreach ($entries as $entry):
                            $clock_in = new DateTime($entry->clock_in);
                            $clock_out = $entry->clock_out ? new DateTime($entry->clock_out) : new DateTime($current_time);
                            $interval = $clock_out->diff($clock_in);
                            $hours = $interval->h + ($interval->days * 24) + ($interval->i / 60);
                            $hours = number_format($hours, 2);
                            ?>
                            <tr>
                                <td><?php echo date('m/d/Y', strtotime($entry->clock_in . ' America/New_York')); ?></td>
                                <td><?php echo date('g:i A', strtotime($entry->clock_in . ' America/New_York')); ?></td>
                                <td><?php echo $entry->clock_out ? date('g:i A', strtotime($entry->clock_out . ' America/New_York')) : 'Active'; ?>
                                </td>
                                <td><?php echo $hours; ?></td>
                                <td style="white-space: normal;"><?php echo $entry->notes ? esc_html($entry->notes) : ''; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
?>